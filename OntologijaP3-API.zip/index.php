<?php
require 'vendor/autoload.php';
require 'bootstrap.php';
use Ungar\Ontologija;
use Ungar\Projekt;
use Composer\Autoload\ClassLoader;

Flight::route('GET /search', function(){

  $doctrineBootstrap = Flight::entityManager();
  $em = $doctrineBootstrap->getEntityManager();
  $repozitorij=$em->getRepository('Ungar\Ontologija');
  $zapisi = $repozitorij->findAll();
  echo $doctrineBootstrap->getJson($zapisi);
});

Flight::route('POST /', function(){

  $foaf = \EasyRdf\Graph::newAndLoad('http://bornaungar.me/ungar.rdf');
  foreach ($foaf->resources() as $resource) {

    $name = $foaf->get($resource, 'foaf:name');
    //$type = $foaf->get($resource, 'rdf:type');
    //echo $name . '<br/>' . $type . '<br/><br/>';

    if($name != ''){

      $ontologija = new Ontologija();
      $ontologija->setPodaci(Flight::request()->data);

      $ontologija->setNaziv($name);

      $doctrineBootstrap = Flight::entityManager();
      $em = $doctrineBootstrap->getEntityManager();

      $em->persist($ontologija);
      $em->flush();
    }
  }

  //$info = $foaf->dump();
  //echo $info;
  ?>

  <?php
});

$cl = new ClassLoader('Ungar', __DIR__, '/src');
$cl->register();
require_once 'bootstrap.php';
Flight::register('entityManager', 'DoctrineBootstrap');

Flight::start();
