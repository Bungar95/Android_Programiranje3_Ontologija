create database bungar_19 default character set utf8;
use bungar_19;
create table ontologija(
    sifra int not null primary key auto_increment,
    naziv varchar(255) not null
);
insert into ontologija(naziv) values ("Test");
